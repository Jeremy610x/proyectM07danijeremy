<?php

$arrayDeportes = ["Fútbol", "Baloncesto", "Natación", "Atletismo", "Ciclismo","pepe"];
$arrayCategorias = ["infantil", "juvenil", "Adulto", "nuevaCategoria"];

$userData = [
    'username' => 'pau',
    'password' => '123'
];
?>