

<?php

function datosPersonalesHtml(){
    $datosP = <<<datosPersonales
                    <fieldset>

                    <legend>Datos Personales</legend>
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" required>
                    <br>
                    <label for="apellidos">Apellidos:</label>
                    <input type="text" id="apellidos" name="apellidos" required>

                    <label for="telefono">Teléfono (No requerido):</label>
                    <input type="tel" id="telefono" name="telefono">
                    <br>
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                    <br>
                    <label for="dni">DNI:</label>
                    <input type="text" id="dni" name="dni" required>

                    <label for="fecha-nacimiento">Fecha de Nacimiento (No requerido):</label>
                    <input type="date" id="fecha-nacimiento" name="fecha-nacimiento">
                    </fieldset>
            datosPersonales;
    echo $datosP;
}

function direccionResidenciaHtml(){
    $direccion = <<<direccion
            <fieldset>
            <legend>Dirección de Residencia</legend>
            <label for="calle">Calle:</label>
            <input type="text" id="calle" name="calle" required>

            <label for="ciudad">Ciudad:</label>
            <input type="text" id="ciudad" name="ciudad" required>
            <br>
            <label for="codigo-postal">Código Postal:</label>
            <input type="text" id="codigo-postal" name="codigo-postal" required>
            </fieldset>
            direccion;
    echo $direccion;
}

function seleccionDeporteHtml($deportes, $categorias){
    
    $opcionesDeporte = ""; 
    $opcionesCategoria="";

    //RECORREMOS EL ARRAY QUE ENTRE, DEPORTES EN ESTE CASO
    foreach ($deportes as $deporte) {
        $opcionesDeporte .= '<option value="' . $deporte . '">' . $deporte . '</option>'; // Agrega cada opción
    }

    // Genera el formulario usando heredoc
    $opcionesDeportesFinal = <<<FORMDEPORTES
            <fieldset>
            <legend>Selección de Eventos</legend>
            <label for="deporte">Selecciona el tipo de deporte:</label>
            <select id="deporte" name="deporte" required>
            $opcionesDeporte
            </select>

            FORMDEPORTES;

    echo ($opcionesDeportesFinal); // imprime selects por cada deporte

    foreach ($categorias as $categoria) {
        $opcionesCategoria .='<option value="'.$categoria.'">'.$categoria.'</option>"';
        //OTRA MANERA DE PONERLO --> "<option value=\"$categoria\">$categoria</option>";
    }

    $opcionesCategoriasFinal = <<<FORMCATEGORIAS
 
    <label for="deporte">Selecciona el tipo de deporte:</label>
    <select id="deporte" name="deporte" required>
    $opcionesCategoria
    </select>
    </fieldset>
    FORMCATEGORIAS;

    echo($opcionesCategoriasFinal);
}

function preferenciasDeportivasHtml(){
    $preferencias = <<<PREFERENCIASDEPORTIVAS

                    <fieldset>
                    <legend>Preferencias Deportivas</legend>
                    <div id="futbol-preferencias" class="deporte-preferencias">
                    <label>Si has elegido Fútbol elige una preferencia:</label>
                    <label>
                    <input type="radio" name="futbol-preferencia" value="jugador"> Jugador
                    </label>
                    <label>
                    <input type="radio" name="futbol-preferencia" value="arbitro"> Árbitro
                    </label>
                    </div>
                    
                    <div id="ciclismo-preferencias" class="deporte-preferencias">
                    <label>Si has elegido Ciclismo elige una preferencia:</label>
                    <label>
                    <input type="radio" name="ciclismo-preferencia" value="carrera-corta"> Carrera Corta
                    </label>
                    <label>
                    <input type="radio" name="ciclismo-preferencia" value="carrera-larga"> Carrera Larga
                    </label>
                    </div>
                    </fieldset>
            PREFERENCIASDEPORTIVAS;
    echo $preferencias;
}




?>





