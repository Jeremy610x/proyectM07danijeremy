<?php

session_start();


require_once './datos/datos.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = isset($_REQUEST['username']) ? $_REQUEST['username'] : null;
    $password = isset($_REQUEST['password']) ? $_REQUEST['password'] : null;

    if ($userData['username'] === $username && $userData['password'] === $password) {
   
        $_SESSION['userlogin'] = $username;

        header('Location: perfil.php');
        exit();
    } else {
        echo '<p style="color: red">El nombre de usuario o la contraseña son incorrectos.</p>';
    }
}

require_once './functions/estructura_eventos.php'; 
myHeader();
myNavBar();
?>

<body>
    <section>
        <h2>Iniciar Sesión</h2>
        <form action="login.php" method="POST">
            <label for="username">Nombre de Usuario:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Iniciar Sesión</button>
        </form>
    </section>
</body>

<?php
myFooter();
?>







