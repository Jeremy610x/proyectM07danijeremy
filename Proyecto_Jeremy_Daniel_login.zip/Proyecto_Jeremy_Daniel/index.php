<?php
require_once './functions/estructura_eventos.php';
myHeader();
myNavBar();
?>
<body>
<?php
mainIndex();
?>


</body>
<?php
myFooter()
?>
</html>