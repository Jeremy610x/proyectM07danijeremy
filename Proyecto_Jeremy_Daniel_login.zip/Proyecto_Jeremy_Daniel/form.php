<?php
require_once './functions/estructura_eventos.php';
require_once './partesFormulario.php';
require_once './datos/datos.php';

myHeader();
myNavBar();
?>
<body class="bodyForm">

      <form action="" method="POST">

     <?php

     //ENSEÑAR FORMULARIO
        datosPersonalesHtml();
        direccionResidenciaHtml();
        seleccionDeporteHtml($arrayDeportes, $arrayCategorias);
        preferenciasDeportivasHtml();




//----------VALIDACIONES/SANEAMIENTO DATOS PERSONALES------------------------------
if ($_SERVER["REQUEST_METHOD"] == "POST") {

//----------------------VALIDAR Y SANEAR NOMBRES Y APELLIDOS-------------------------------
    $nombre = filter_var($_POST['nombre'], FILTER_SANITIZE_SPECIAL_CHARS);
    $apellidos = filter_var($_POST['apellidos'], FILTER_SANITIZE_SPECIAL_CHARS);

    if (!ctype_alpha($nombre)) {
        echo "El nombre solo puede contener letras sin espacios ni caracteres especiales.<br>";
    } else {
        echo "Nombre: " . $nombre . "<br>";
    }
    
    if (!ctype_alpha($apellidos)) {
        echo "Los apellidos solo pueden contener letras sin espacios ni caracteres especiales.<br>";
    } else {
        echo "Apellidos: " . $apellidos . "<br>";
    }
//----------------------VALIDAR Y SANEAR TELEFONO-------------------------------
 $telefono = filter_var($_POST['telefono'], FILTER_SANITIZE_NUMBER_INT);
 if (strlen($telefono) !== 9) {
    echo "El teléfono debe contener exactamente 9 dígitos.<br>";
} else {
    echo "Teléfono: " . $telefono . "<br>";
}
//----------------------VALIDAR Y SANEAR DNI, CORREO, EMAIL-------------------------------

//SANEADOS
$dni = filter_var($_POST['dni'], FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
$fechaNacimiento = filter_var($_POST['fecha-nacimiento'], FILTER_SANITIZE_SPECIAL_CHARS);

//VALIDACION DNI
//el primer or pide que dni no sea diferente de 9, el segundo pide que los primeros 8 caracteres sean numeros
//el tercero saca el ultimo caracter y pide que sea una letra.
if (strlen($dni) !== 9 || !is_numeric(substr($dni, 0, 8)) || !ctype_alpha(substr($dni, 8))) {
    echo "El DNI debe tener 8 dígitos seguidos de una letra.<br>";
} else {
    echo "DNI: " . $dni . "<br>";
}
//VALIDACION EMAIL
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "El email no es válido.<br>";
} else {
    echo "Email: " . $email . "<br>";
}

//FALTA VALIDACION FECHA DE NACIMIENTO
//

//----------VALIDACIONES/SANEAMIENTO DIRECCION DE RESIDENCIA-----------------------------

//SANEAMIENTO CALLE, CIUDAD Y CP
$calle = filter_var($_POST['calle'], FILTER_SANITIZE_SPECIAL_CHARS);
$ciudad = filter_var($_POST['ciudad'], FILTER_SANITIZE_SPECIAL_CHARS);
$codigoPostal = filter_var($_POST['codigo-postal'], FILTER_SANITIZE_NUMBER_INT);

//validar calle
if (empty($calle)) {
    echo "La calle no puede estar vacía.<br>";
} else {
    echo "Calle: " . $calle . "<br>";
}

// Validar ciudad
if (empty($ciudad)) {
    echo "La ciudad no puede estar vacía.<br>";
} else {
    echo "Ciudad: " . $ciudad . "<br>";
}

// Validar código postal
if (empty($codigoPostal)) {
    echo "El código postal no puede estar vacío.<br>";
    //si codigo postal es diferente de 5 digitos y no es numerico
} elseif (strlen($codigoPostal) !== 5 || !is_numeric($codigoPostal)) {
    echo "El código postal debe contener exactamente 5 dígitos numéricos.<br>";
} else {
    echo "Código Postal: " . $codigoPostal . "<br>";
}


}

//RECOGER PREFERENCIAS FUTBOL Y CICLISMO

// Recoger la preferencia de fútbol
if (isset($_POST['futbol-preferencia'])) {
    $preferenciaFutbol = $_POST['futbol-preferencia'];
    echo "Preferencia de fútbol seleccionada: " . $preferenciaFutbol;
}

// Recoger la preferencia de ciclismo
if (isset($_POST['ciclismo-preferencia'])) {
    $preferenciaCiclismo = $_POST['ciclismo-preferencia'];
    echo "Preferencia de ciclismo seleccionada: " . $preferenciaCiclismo;
}

?>



<!-- 
        <fieldset>
            <legend>Selección de Nivel</legend>
            <label>Nivel de habilidad:</label>
            <label>
                <input type="radio" name="nivel" value="principiante" required> Principiante
            </label>
            <label>
                <input type="radio" name="nivel" value="intermedio"> Intermedio
            </label>
            <label>
                <input type="radio" name="nivel" value="avanzado"> Avanzado
            </label>
        </fieldset>

        <fieldset>
            <legend>Camiseta de Participación</legend>
            <label>
                <input type="checkbox" name="camiseta" id="camiseta"> ¿Deseas recibir una camiseta personalizada por 5€?
            </label>

            <label for="talla">Selecciona la talla:</label>
            <select id="talla" name="talla">
                <option value="s">S</option>
                <option value="m">M</option>
                <option value="l">L</option>
                <option value="xl">XL</option>
            </select>
        </fieldset>  -->

        <button type="submit">Enviar Inscripción</button>
    </form>
</body>

<?php
myFooter()
?>
</html>