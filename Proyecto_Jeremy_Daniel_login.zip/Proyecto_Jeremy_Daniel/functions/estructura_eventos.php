<!-- FUNCIONES ESTRUCTURA EVENTOS DEPORTIVOS -->


<?php

//------------------------------------------------------------------------------------------------------------
function myHeader()
{
    $head = <<<CABECERA
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pagina Principal</title>
        <link rel="stylesheet" href="./css/style.css">


    </head>
    CABECERA;
    echo $head;
}

function myNavBar()
{
    $menu = <<<HERE
            <div class="navbar">
            <a href="./index.php">Inicio</a>
            <div class="dropdown">
            <button class="dropbtn">Eventos</button>
            <div class="dropdown-content">
            <a href="#futbol">Fútbol</a>
            <a href="#baloncesto">Baloncesto</a>
            <a href="#natacion">Natación</a>
            <a href="#atletismo">Atletismo</a>
            <a href="#ciclismo">Ciclismo</a>
            </div>
            </div>
            <a href="./form.php">Formulario de Inscripción</a>
            <a href="./login.php">Login</a>
            </div>
            HERE;
    echo $menu;
    echo '<hr>';
}

function myFooter()
{
    $footerHTML = <<<MYFOOTER
        <footer>
        <p>Autores : Jeremy y Daniel DAW2 M07</p>
        <div class="socialIcons">
            <a href="https://www.instagram.com/?hl=es"><img class="iconSocial" src="./img/icons/instagram.png"></a>
            <a href="https://www.facebook.com/"><img class="iconSocial" src="./img/icons/facebook.png"></a>
            <a href="https://x.com/"><img class="iconSocial" src="./img/icons/x.png"></a>
            
        </div>
        <p>Somos una organizacion de inscripción de usuarios en diferentes eventos deportivos.</p>
        <p>Derechos reservados 2024</p>
        </footer>
        
        MYFOOTER;
    echo $footerHTML;

}

function mainIndex()
{
    $footerHTML = <<<MYMAIN
        <section>
        <h2>BIENVENIDO A LOS EVENTOS DEPORTIVOS!</h2>
        <img src="./img/img.jpg" alt="img_Eventos_Deportivos" title="imagenPrincipal">


        </section>

        
        MYMAIN;
    echo $footerHTML;

}


?>